'use client'

import { useState, useEffect, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { 
  Send, 
  Plus, 
  MessageSquare, 
  Trash2, 
  User, 
  Bot, 
  MoreHorizontal,
  AlertCircle,
  Loader2,
  Copy,
  RotateCcw,
  Check
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { cn } from '@/lib/utils'

interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: string
  isStreaming?: boolean
}

interface Chat {
  _id: string
  title: string
  updatedAt: string
  messages: Message[]
}

export default function ModernChatPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [chats, setChats] = useState<Chat[]>([])
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [copiedMessageId, setCopiedMessageId] = useState<string | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  // Redirect if not authenticated
  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/signin')
    }
  }, [status, router])

  useEffect(() => {
    if (session) {
      fetchChats()
    }
  }, [session])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  useEffect(() => {
    adjustTextareaHeight()
  }, [input])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  const adjustTextareaHeight = () => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto'
      const newHeight = Math.min(textareaRef.current.scrollHeight, 120) // Reduced max height
      textareaRef.current.style.height = `${newHeight}px`
    }
  }

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp)
    const now = new Date()
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60)
    
    if (diffInHours < 1) {
      const minutes = Math.floor(diffInHours * 60)
      return minutes < 1 ? 'Just now' : `${minutes}m ago`
    } else if (diffInHours < 24) {
      return `${Math.floor(diffInHours)}h ago`
    } else {
      return date.toLocaleDateString()
    }
  }

  const copyToClipboard = async (text: string, messageId: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedMessageId(messageId)
      setTimeout(() => setCopiedMessageId(null), 2000)
    } catch (error) {
      console.error('Failed to copy:', error)
    }
  }

  async function fetchChats() {
    try {
      setError(null)
      const response = await fetch('/api/chat')
      if (response.ok) {
        const data = await response.json()
        setChats(data.data.chats || [])
      } else {
        throw new Error('Failed to fetch chats')
      }
    } catch (error) {
      console.error('Failed to fetch chats:', error)
      setError('Failed to load chats. Please refresh the page.')
    }
  }

  async function loadChat(chatId: string) {
    try {
      setError(null)
      const response = await fetch(`/api/chat/${chatId}`)
      if (response.ok) {
        const data = await response.json()
        const chatMessages = data.data.chat.messages.map((msg: any) => ({
          id: msg._id || Math.random().toString(),
          role: msg.role,
          content: msg.content,
          timestamp: msg.timestamp || new Date().toISOString()
        }))
        setMessages(chatMessages)
        setSelectedChatId(chatId)
      } else {
        throw new Error('Failed to load chat')
      }
    } catch (error) {
      console.error('Failed to load chat:', error)
      setError('Failed to load chat messages.')
    }
  }

  async function createNewChat() {
    if (!input.trim()) return

    const message = input.trim()
    setInput('')
    setError(null)

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: message.substring(0, 50) + (message.length > 50 ? '...' : ''),
          message: message,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        const newChatId = data.data.chat._id
        await fetchChats()
        await loadChat(newChatId)
        await sendMessage(message, newChatId)
      } else {
        const errorData = await response.json()
        throw new Error(errorData.message || 'Failed to create chat')
      }
    } catch (error: any) {
      console.error('Failed to create chat:', error)
      setError(error.message || 'Failed to create new chat. Please try again.')
      setInput(message)
    }
  }

  async function sendMessage(message: string, chatId: string) {
    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: message,
      timestamp: new Date().toISOString()
    }

    setMessages(prev => [...prev, userMessage])
    setIsLoading(true)
    setError(null)

    const assistantMessageId = (Date.now() + 1).toString()
    const streamingMessage: Message = {
      id: assistantMessageId,
      role: 'assistant',
      content: '',
      timestamp: new Date().toISOString(),
      isStreaming: true
    }
    setMessages(prev => [...prev, streamingMessage])

    try {
      const response = await fetch(`/api/chat/${chatId}/message`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.message || `Failed to send message: ${response.status}`)
      }

      const reader = response.body?.getReader()
      const decoder = new TextDecoder()
      let assistantContent = ''

      if (reader) {
        while (true) {
          const { done, value } = await reader.read()
          if (done) break

          const chunk = decoder.decode(value)
          const lines = chunk.split('\n')
          
          for (const line of lines) {
            if (line.startsWith('data: ')) {
              const data = line.slice(6)
              if (data === '[DONE]') continue
              
              try {
                const parsed = JSON.parse(data)
                if (parsed.choices?.[0]?.delta?.content) {
                  assistantContent += parsed.choices[0].delta.content
                  
                  setMessages(prev => prev.map(msg => 
                    msg.id === assistantMessageId 
                      ? { ...msg, content: assistantContent }
                      : msg
                  ))
                }
              } catch (parseError) {
                if (data.trim()) {
                  assistantContent += data
                  setMessages(prev => prev.map(msg => 
                    msg.id === assistantMessageId 
                      ? { ...msg, content: assistantContent }
                      : msg
                  ))
                }
              }
            }
          }
        }
      }

      // Mark streaming as complete
      setMessages(prev => prev.map(msg => 
        msg.id === assistantMessageId 
          ? { ...msg, isStreaming: false }
          : msg
      ))

    } catch (error: any) {
      console.error('Failed to send message:', error)
      
      // Remove failed messages
      setMessages(prev => prev.filter(msg => 
        msg.id !== userMessage.id && msg.id !== assistantMessageId
      ))
      
      // Add error message
      const errorMessage: Message = {
        id: Date.now().toString(),
        role: 'assistant',
        content: `Sorry, I encountered an error: ${error.message || 'Please try again.'}`,
        timestamp: new Date().toISOString()
      }
      setMessages(prev => [...prev, errorMessage])
      setError(error.message || 'Failed to get AI response. Please try again.')
    } finally {
      setIsLoading(false)
    }
  }

  const regenerateResponse = async (messageIndex: number) => {
    if (messageIndex === 0 || !selectedChatId) return
    
    const userMessage = messages[messageIndex - 1]
    if (userMessage.role !== 'user') return

    // Remove the assistant message and all messages after it
    setMessages(prev => prev.slice(0, messageIndex))
    
    // Regenerate the response
    await sendMessage(userMessage.content, selectedChatId)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return

    const message = input.trim()
    setInput('')

    if (!selectedChatId) {
      await createNewChat()
    } else {
      await sendMessage(message, selectedChatId)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSubmit(e)
    }
  }

  const deleteChat = async (chatId: string) => {
    if (!confirm('Are you sure you want to delete this chat?')) return
    
    try {
      setError(null)
      const response = await fetch(`/api/chat/${chatId}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' }
      })

      if (response.ok) {
        setChats(prev => prev.filter(chat => chat._id !== chatId))
        
        if (selectedChatId === chatId) {
          setSelectedChatId(null)
          setMessages([])
        }
      } else {
        throw new Error('Failed to delete chat')
      }
    } catch (error: any) {
      console.error('Failed to delete chat:', error)
      setError(error.message || 'Failed to delete chat. Please try again.')
    }
  }

  const startNewChat = () => {
    setSelectedChatId(null)
    setMessages([])
    setInput('')
    setError(null)
    setTimeout(() => {
      textareaRef.current?.focus()
    }, 100)
  }

  if (status === 'loading') {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="h-4 w-4 animate-spin mr-2" />
        <span>Loading...</span>
      </div>
    )
  }

  if (status === 'unauthenticated') {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <AlertCircle className="h-8 w-8 text-destructive mx-auto mb-2" />
          <p>Redirecting to sign in...</p>
        </div>
      </div>
    )
  }

  const selectedChat = chats.find(chat => chat._id === selectedChatId)

  return (
    <div className="h-screen w-full flex bg-background overflow-hidden">
      {/* Error Alert */}
      {error && (
        <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-50 w-full max-w-md px-4">
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              {error}
              <Button 
                variant="ghost" 
                size="sm" 
                className="ml-2 h-auto p-0"
                onClick={() => setError(null)}
              >
                ×
              </Button>
            </AlertDescription>
          </Alert>
        </div>
      )}

      {/* Sidebar */}
      <div className="w-80 h-full border-r bg-muted/5 flex flex-col">
        {/* Sidebar Header */}
        <div className="p-3 border-b flex-shrink-0">
          <Button onClick={startNewChat} className="w-full justify-start gap-2" disabled={isLoading}>
            <Plus className="h-4 w-4" />
            New Chat
          </Button>
        </div>

        {/* Chat List */}
        <div className="flex-1 overflow-hidden">
          <ScrollArea className="h-full p-2">
            <div className="space-y-1">
              {chats.map((chat) => (
                <div
                  key={chat._id}
                  className={cn(
                    "group relative flex items-center gap-3 rounded-lg p-2 cursor-pointer hover:bg-muted/50 transition-colors",
                    selectedChatId === chat._id ? 'bg-muted' : ''
                  )}
                  onClick={() => !isLoading && loadChat(chat._id)}
                >
                  <MessageSquare className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{chat.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatTime(chat.updatedAt)}
                    </p>
                  </div>
                  
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-7 w-7 p-0">
                          <MoreHorizontal className="h-3 w-3" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem 
                          onClick={(e) => {
                            e.stopPropagation()
                            deleteChat(chat._id)
                          }}
                          className="text-destructive"
                          disabled={isLoading}
                        >
                          <Trash2 className="h-3 w-3 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              ))}
              
              {chats.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No chats yet</p>
                  <p className="text-xs">Start a conversation</p>
                </div>
              )}
            </div>
          </ScrollArea>
        </div>

        {/* User Profile */}
        <div className="p-3 border-t flex-shrink-0">
          <div className="flex items-center gap-3">
            <Avatar className="h-8 w-8">
              <AvatarImage src={session?.user?.image || ''} />
              <AvatarFallback>
                <User className="h-4 w-4" />
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">
                {session?.user?.name || session?.user?.email}
              </p>
              <p className="text-xs text-muted-foreground">
                {session?.user?.role || 'User'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 h-full flex flex-col">
        {selectedChat ? (
          <>
            {/* Chat Header */}
            <div className="border-b p-3 bg-background flex-shrink-0">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-lg font-semibold truncate">{selectedChat.title}</h1>
                  <p className="text-sm text-muted-foreground">
                    {messages.length} messages
                  </p>
                </div>
                {isLoading && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Loader2 className="h-3 w-3 animate-spin" />
                    <span className="hidden sm:inline">AI responding...</span>
                  </div>
                )}
              </div>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-hidden">
              <ScrollArea className="h-full">
                <div className="p-4">
                  <div className="max-w-4xl mx-auto space-y-4">
                    {messages.map((message, index) => (
                      <div
                        key={message.id}
                        className={cn(
                          "group flex gap-3",
                          message.role === 'user' ? 'justify-end' : 'justify-start'
                        )}
                      >
                        {message.role === 'assistant' && (
                          <Avatar className="h-7 w-7 flex-shrink-0">
                            <AvatarFallback className="bg-primary text-primary-foreground">
                              <Bot className="h-3 w-3" />
                            </AvatarFallback>
                          </Avatar>
                        )}
                        
                        <div className={cn(
                          "flex flex-col max-w-[80%]",
                          message.role === 'user' ? 'items-end' : 'items-start'
                        )}>
                          <div
                            className={cn(
                              "rounded-2xl px-3 py-2 shadow-sm",
                              message.role === 'user'
                                ? 'bg-primary text-primary-foreground'
                                : 'bg-muted border'
                            )}
                          >
                            <div className="whitespace-pre-wrap break-words text-sm">
                              {message.content}
                              {message.isStreaming && (
                                <span className="inline-block w-1 h-4 bg-current animate-pulse ml-1" />
                              )}
                            </div>
                          </div>
                          
                          {/* Message actions */}
                          <div className="flex items-center gap-1 mt-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <span className="text-xs text-muted-foreground px-1">
                              {formatTime(message.timestamp)}
                            </span>
                            
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-5 px-1"
                              onClick={() => copyToClipboard(message.content, message.id)}
                            >
                              {copiedMessageId === message.id ? (
                                <Check className="h-3 w-3" />
                              ) : (
                                <Copy className="h-3 w-3" />
                              )}
                            </Button>
                            
                            {message.role === 'assistant' && !message.isStreaming && (
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-5 px-1"
                                onClick={() => regenerateResponse(index)}
                                disabled={isLoading}
                              >
                                <RotateCcw className="h-3 w-3" />
                              </Button>
                            )}
                          </div>
                        </div>

                        {message.role === 'user' && (
                          <Avatar className="h-7 w-7 flex-shrink-0">
                            <AvatarImage src={session?.user?.image || ''} />
                            <AvatarFallback>
                              <User className="h-3 w-3" />
                            </AvatarFallback>
                          </Avatar>
                        )}
                      </div>
                    ))}
                    
                    <div ref={messagesEndRef} />
                  </div>
                </div>
              </ScrollArea>
            </div>

            {/* Input Area */}
            <div className="border-t p-3 bg-background flex-shrink-0">
              <form onSubmit={handleSubmit} className="max-w-4xl mx-auto">
                <div className="flex items-end gap-2 bg-muted/50 rounded-xl p-2 border">
                  <textarea
                    ref={textareaRef}
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Type your message..."
                    disabled={isLoading}
                    className="flex-1 resize-none bg-transparent border-0 outline-none placeholder:text-muted-foreground min-h-[36px] max-h-[120px] py-2 text-sm"
                    rows={1}
                  />
                  
                  <Button
                    type="submit"
                    disabled={!input.trim() || isLoading}
                    size="sm"
                    className="h-9 w-9 p-0 rounded-lg flex-shrink-0"
                  >
                    {isLoading ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                  </Button>
                </div>
                
                <p className="text-xs text-muted-foreground text-center mt-1">
                  Press Enter to send, Shift+Enter for new line
                </p>
              </form>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col">
            {/* Welcome Content */}
            <div className="flex-1 flex flex-col items-center justify-center p-8">
              <div className="max-w-md text-center space-y-6">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                  <Bot className="h-8 w-8 text-primary" />
                </div>
                
                <div className="space-y-2">
                  <h1 className="text-2xl font-bold">How can I help you today?</h1>
                  <p className="text-muted-foreground">
                    Start a new conversation below
                  </p>
                </div>
              </div>
            </div>

            {/* Input Area for New Chat */}
            <div className="border-t p-3 bg-background flex-shrink-0">
              <form onSubmit={handleSubmit} className="max-w-4xl mx-auto">
                <div className="flex items-end gap-2 bg-muted/50 rounded-xl p-2 border">
                  <textarea
                    ref={textareaRef}
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Start a new conversation..."
                    disabled={isLoading}
                    className="flex-1 resize-none bg-transparent border-0 outline-none placeholder:text-muted-foreground min-h-[36px] max-h-[120px] py-2 text-sm"
                    rows={1}
                  />
                  
                  <Button
                    type="submit"
                    disabled={!input.trim() || isLoading}
                    size="sm"
                    className="h-9 w-9 p-0 rounded-lg flex-shrink-0"
                  >
                    {isLoading ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                  </Button>
                </div>
                
                <p className="text-xs text-muted-foreground text-center mt-1">
                  Press Enter to send, Shift+Enter for new line
                </p>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
